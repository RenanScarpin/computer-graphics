import math
import numpy as np

num_vertices = 12
pi = math.pi
radius = 0.2

# Generates circle vertices
vertices = np.zeros((num_vertices, 3), dtype=np.float32)
angle = 0.0
for i in range(num_vertices):
    angle += 2 * pi / num_vertices
    x = math.cos(angle) * radius
    y = math.sin(angle) * radius
    vertices[i] = [x, y, 0]
center = np.array([[0.0, 0.0, 0.0]], dtype=np.float32)
final_vertices = np.vstack([center, vertices])

# Generates faces
faces = []
for i in range(num_vertices):
    a = 1
    b = i + 2
    c = ((i + 1) % num_vertices) + 2
    faces.append((a, b, c))

# Writes to file
with open("fan.txt", "w", encoding="utf-8") as f:
    for x, y, z in final_vertices:
        f.write(f"v {x} {y} {z}\n")

    for a, b, c in faces:
        f.write(f"f {a} {b} {c}\n")
